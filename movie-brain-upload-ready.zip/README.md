# Movie Brain

GitHub repository mein files upload karne ke baad **Actions** tab se debug APK build hota hai.
