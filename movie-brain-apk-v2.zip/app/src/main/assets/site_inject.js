(async () => {
  const P = __P__;
  const ORI = __O__;
  const F = __F__;
  const IS_EXTEND = __EXT__;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const rep = (s, d) => Bot.report(s, d || '');

  const isVisible = el => !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));

  const findPromptBox = () => {
    const els = [
      ...document.querySelectorAll('textarea'),
      ...document.querySelectorAll('[contenteditable="true"], [role="textbox"]')
    ].filter(isVisible);

    if (IS_EXTEND) {
      const nextBox = els.find(el => /describe how the video continues|what happens next|next part|continue/i.test(
        (el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('aria-label') || '')
      ));
      if (nextBox) return nextBox;
    }

    return els.find(el => /enter your prompt|prompt/i.test(
      (el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('aria-label') || '')
    )) || els[0];
  };

  const setPromptText = async (box, text) => {
    box.scrollIntoView({ behavior: 'instant', block: 'center' });
    box.focus();
    await sleep(250);
    if (box.tagName === 'TEXTAREA' || box.tagName === 'INPUT') {
      const proto = box.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
      setter.call(box, text);
      box.dispatchEvent(new Event('input', { bubbles: true }));
      box.dispatchEvent(new Event('change', { bubbles: true }));
    } else {
      document.execCommand('selectAll', false, null);
      document.execCommand('insertText', false, text);
      box.dispatchEvent(new InputEvent('input', { bubbles: true, data: text, inputType: 'insertText' }));
    }
    await sleep(500);
  };

  const findSubmitBtn = () => {
    const btns = [...document.querySelectorAll('button, [role="button"]')].filter(isVisible);
    if (IS_EXTEND) {
      const nextPartBtn = btns.find(b => /\bgenerate\s*next\s*part\b/i.test((b.innerText || '').trim()));
      if (nextPartBtn) return nextPartBtn;
    }
    return btns.find(b => /\bgenerate\b/i.test((b.innerText || '').trim()) && !/regenerat|next\s*part/i.test(b.innerText || ''))
        || btns.find(b => /generat/i.test((b.innerText || '') + ' ' + (b.getAttribute('aria-label') || '')));
  };

  try {
    if (IS_EXTEND) {
      const alreadyOpen = [...document.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"]')].some(el =>
        isVisible(el) && /describe how the video continues|how the video continues/i.test(el.getAttribute('placeholder') || '')
      );
      if (!alreadyOpen) {
        let extBtn = null;
        for (let k = 0; k < 10 && !extBtn; k++) {
          const btns = [...document.querySelectorAll('button, [role="button"]')].filter(isVisible);
          extBtn = btns.find(b => /\bextend\s*video\b/i.test((b.innerText || '').trim()))
                || btns.find(b => /\bextend\b/i.test((b.innerText || '').trim()));
          if (!extBtn) await sleep(500);
        }
        if (extBtn) {
          extBtn.scrollIntoView({ behavior: 'instant', block: 'center' });
          await sleep(300);
          extBtn.click();
          await sleep(1500);
        }
      }
    } else {
      const lab = [...document.querySelectorAll('label, span, div, button')].find(e =>
        isVisible(e) && e.children.length <= 2 && (e.innerText || '').trim().toLowerCase() === String(ORI || '').toLowerCase());
      if (lab) {
        lab.click();
        await sleep(500);
      }
    }

    let ta = findPromptBox();
    for (let k = 0; k < 20 && !ta; k++) { await sleep(1000); ta = findPromptBox(); }
    if (!ta) {
      rep('error', 'TAAFT prompt / continuation box nahi mila.');
      return;
    }

    await setPromptText(ta, P);

    const currentVal = (ta.value !== undefined ? ta.value : ta.innerText || '').trim();
    if (currentVal.length < 5) {
      rep('error', 'Prompt box me text paste nahi hua.');
      return;
    }

    let gb = findSubmitBtn();
    for (let k = 0; k < 12 && (!gb || gb.disabled); k++) { await sleep(500); gb = findSubmitBtn(); }
    if (!gb || gb.disabled) {
      rep('error', 'Generate / Generate next part button nahi mila ya disabled hai.');
      return;
    }

    gb.scrollIntoView({ behavior: 'instant', block: 'center' });
    await sleep(300);

    const getPartsCount = () => {
      const m = (document.body.innerText || '').match(/(\d+)\s*parts/i);
      return m ? parseInt(m[1], 10) : 0;
    };

    const partsBefore = getPartsCount();
    const btnLabelBefore = (gb.innerText || '').trim();
    gb.click();
    rep('started', (IS_EXTEND ? 'Next part bheja (' : 'Clip 1 bheja (') + P.length + ' akshar)');

    let sawStarted = false;
    const tStart = Date.now();
    while (Date.now() - tStart < 30000) {
      await sleep(1000);
      const b = findSubmitBtn();
      const curParts = getPartsCount();
      if (!b || b.disabled || curParts > partsBefore || /generat(ing|ed)|cancel|queue/i.test((b && b.innerText) || '') || (b && (b.innerText || '').trim() !== btnLabelBefore)) {
        sawStarted = true;
        break;
      }
    }

    const tMax = Date.now();
    while (Date.now() - tMax < 8 * 60 * 1000) {
      await sleep(3000);
      const b = findSubmitBtn();
      const curParts = getPartsCount();
      const hasNextPartBox = [...document.querySelectorAll('textarea')].some(el =>
        isVisible(el) && /describe how the video continues/i.test(el.getAttribute('placeholder') || '')
      );
      const busy = !b || b.disabled || /generat(ing|ed)|cancel|queue/i.test((b && b.innerText) || '');
      if ((sawStarted && !busy && (curParts > partsBefore || hasNextPartBox || (b && !b.disabled))) || (!sawStarted && curParts > partsBefore)) {
        await sleep(2000);
        rep('done', '');
        return;
      }
    }
    rep('error', '8 minute me next part complete nahi hua.');
  } catch (e) {
    rep('error', String(e));
  }
})();