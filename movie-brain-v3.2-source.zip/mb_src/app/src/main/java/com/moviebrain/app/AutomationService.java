package com.moviebrain.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

public class AutomationService extends Service {
    public static final String ACTION_START = "com.moviebrain.app.action.START_AUTOMATION";
    public static final String ACTION_STOP = "com.moviebrain.app.action.STOP_AUTOMATION";
    public static final String ACTION_UPDATE = "com.moviebrain.app.action.UPDATE_AUTOMATION";
    private static final String CHANNEL_ID = "movie_brain_automation";
    private static final int NOTIFICATION_ID = 4107;
    private PowerManager.WakeLock wakeLock;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            getSharedPreferences("mb", MODE_PRIVATE).edit().putBoolean("automation_active", false).apply();
            stopSelf();
            return START_NOT_STICKY;
        }
        getSharedPreferences("mb", MODE_PRIVATE).edit().putBoolean("automation_active", true).apply();
        String detail = intent == null ? null : intent.getStringExtra("detail");
        String body = detail == null || detail.trim().isEmpty() ? "Movie Brain automation session is active" : detail;
        startForeground(NOTIFICATION_ID, buildNotification("Movie Brain • Auto Extend", body));
        acquireWakeLock();
        return START_STICKY;
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null && (wakeLock == null || !wakeLock.isHeld())) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MovieBrain:Automation");
                wakeLock.acquire(6 * 60 * 60 * 1000L);
            }
        } catch (Exception ignored) { }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Movie Brain automation", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Shows when Auto Extend is active");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String title, String body) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle(title).setContentText(body).setContentIntent(pi).setOngoing(true).setOnlyAlertOnce(true);
        return b.build();
    }

    @Override public void onDestroy() {
        getSharedPreferences("mb", MODE_PRIVATE).edit().putBoolean("automation_active", false).apply();
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) { }
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE); else stopForeground(true);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
