# Movie Brain 3.2 (source update)

## Is update mein
- Auto Extend start/stop par Android Foreground Service start hoti hai.
- Ongoing notification mein current clip ka status dikhaya jata hai.
- Partial WakeLock service ko background mein CPU sleep se bachane ki koshish karta hai (maximum 6 ghante).
- Android 13+ notification permission request hoti hai.
- Existing project data, prompts, API-key page, import/export aur TAAFT WebView flow ko preserve kiya gaya hai.
- Build version 3.2 / versionCode 6.

## Bahut zaroori limitation
Foreground Service app process ko zinda rakhne aur notification/WakeLock ke liye hai. TAAFT ka page abhi Activity ke WebView mein chalta hai, service ke andar independent browser engine nahi hai. Android background mein WebView JavaScript ko throttle/pause kar sakta hai, aur TAAFT apni taraf se session/queue rok sakta hai. Isliye app minimize karne par uninterrupted clip-to-clip generation abhi guaranteed nahi hai. Phone par real test zaroori hai. App ko Recent Apps se swipe karke force-close na karein; Android Settings se Force stop karne par service bhi band ho jayegi.

## Build APK
1. Is folder ko Android Studio mein Open karein.
2. Gradle sync complete hone dein (JDK 17, Android Gradle Plugin 8.5.2, Gradle 8.7).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK: `app/build/outputs/apk/debug/app-debug.apk`

GitHub Actions workflow bhi included hai: repository mein push karein ya Actions > Build Movie Brain APK > Run workflow chalayein. Workflow artifact mein debug APK milega.

## Test checklist
1. APK install karke TAAFT login karein.
2. Sirf 2 test clips se Auto Extend test karein.
3. Notification permission allow karein.
4. App ko Home dabakar minimize karein, force-stop na karein.
5. Dekhein kya TAAFT ka render aur next Extend waqai continue hota hai.
6. Phone model/Android battery settings ke hisaab se battery optimization restrictions alag ho sakti hain.
